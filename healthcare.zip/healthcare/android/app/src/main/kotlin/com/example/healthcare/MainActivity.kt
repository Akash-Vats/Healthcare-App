package com.example.healthcare

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
